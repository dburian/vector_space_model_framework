from src.experiments import run_0


class Run1(run_0.Run0WeightingModel):
    pass
